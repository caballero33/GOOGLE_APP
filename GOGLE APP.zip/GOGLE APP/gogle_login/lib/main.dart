import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Google Account',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: GoogleAccountPage(),
    );
  }
}

class GoogleAccountPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Color.fromARGB(241, 243, 249, 250),
          title: Row(
            children: [
              Icon(Icons.close),
              SizedBox(width: 8),
              Text('Cuenta de Google'),
            ],
          ),
          actions: [
            IconButton(
              icon: Icon(Icons.help),
              onPressed: () {},
            ),
            IconButton(
              icon: Icon(Icons.search),
              onPressed: () {},
            ),
            IconButton(
              icon: Icon(Icons.person_rounded),
              onPressed: () {},
            ),
          ],
          bottom: TabBar(
            tabs: [
              Tab(text: 'Página principal'),
              Tab(text: 'Información personal'),
              Tab(text: 'Datos y privacidad'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            ListView(
              padding: EdgeInsets.all(16),
              children: [
                ListTile(
                  title: Text('Tu cuenta está protegida'),
                  subtitle: Text(
                      'La verificación de seguridad revisó tu cuenta y no encontró acciones recomendadas'),
                  trailing:
                      Icon(Icons.check_circle, size: 50, color: Colors.green),
                ),
                Padding(
                  padding: EdgeInsets.all(16),
                  child: Text(
                    'Ver detalles',
                    style: TextStyle(
                      color: Colors.blue,
                      fontSize: 12,
                      fontWeight: FontWeight.normal,
                    ),
                  ),
                ),
                Divider(),
                ListTile(
                  title: Text('Verificación de privacidad'),
                  subtitle: Text(
                      'Elige la configuración de privacidad indicada para ti con esta guía paso a paso'),
                  trailing: Icon(
                    Icons.shield_moon_outlined,
                    size: 60,
                    color: Colors.blue,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 16, bottom: 8),
                  child: Text(
                    'Realizar la Verificación de privacidad',
                    style: TextStyle(
                      color: Color.fromARGB(255, 25, 144, 242),
                      fontSize: 12,
                      fontWeight: FontWeight.normal,
                    ),
                  ),
                ),
                Divider(),
                Text(
                  '¿Buscas otra información?',
                  textAlign: TextAlign.start,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 14,
                  ),
                ),
                Divider(
                  color: Colors.white,
                ),
                ListTile(
                  leading: Icon(Icons.search),
                  title: Text('Buscar cuenta de Google'),
                ),
                ListTile(
                  leading: Icon(Icons.help_outline),
                  title: Text('Tus datos'),
                ),
                ListTile(
                  leading: Icon(Icons.feedback_outlined),
                  title: Text('Enviar comentarios'),
                ),
                SizedBox(height: 16),
                Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Divider(),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Expanded(
                            child: Text(
                              'Solo tú puedes ver esta configuración. También puedes revisar la configuración de Maps, la Búsqueda o cualquier servicio de Google que uses con frecuencia. y la seguridad de tus datos ',
                              textAlign: TextAlign.justify,
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                          ),
                          Icon(
                            Icons.shield_moon_outlined,
                            color: Colors.blue,
                            size: 60,
                          ),
                        ],
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'Mas informacion ',
                          style: TextStyle(
                            color: Colors.blue,
                            fontSize: 10,
                            fontWeight: FontWeight.normal,
                          ),
                        ),
                        Icon(
                          Icons.help,
                          color: Colors.blue,
                          size: 16,
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
            Center(child: Text('"Información personal"')),
            Center(child: Text('"Datos y privacidad"')),
          ],
        ),
      ),
    );
  }
}
